<?php getHeader();?>

	<section class="cart pb_50 min600">
		<div class="title_bg text-center">
			<h3 class="rs">Đăng ký nhận khuyến mại</h3>
			<ul class="list-inline rs">
				<li class="list-inline-item"><a href="/">Trang chủ</a></li>
				<li class="list-inline-item"><i class="fa fa-angle-right" aria-hidden="true"></i></li>
				<li class="list-inline-item">Đăng ký nhận khuyến mại</li>
			</ul>
		</div>
		<div class="container">
			<div class="cart_main">
				<div class="p40 text-align">Chúng tôi sẽ gửi cho bạn các chương trình khuyến mại của chúng tôi. Cảm ơn bạn đã tin tưởng sử dụng sản phẩm Trứng gà Dabaco.</div>
			</div>
		</div>
	</section>
<?php getFooter(); ?>